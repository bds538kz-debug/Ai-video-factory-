
import streamlit as st, os, json

# Streamlit Cloud secrets -> environment variables
for _k in ["OPENAI_API_KEY","TEXT_MODEL","IMAGE_MODEL","TTS_MODEL","TTS_VOICE"]:
    if _k in st.secrets and st.secrets[_k]: os.environ[_k] = str(st.secrets[_k])
from factory import analyze_reference, make_concepts, make_script, generate_assets, render_video

st.set_page_config(page_title="AI Shorts Factory 3.0", page_icon="🎬", layout="centered")
st.markdown("""<style>
.block-container{max-width:820px;padding:1rem}
.stButton>button{width:100%;min-height:48px;font-weight:700}
.step{padding:10px 14px;border-radius:12px;border:1px solid #ddd;margin:6px 0}
</style>""",unsafe_allow_html=True)

st.title("🎬 AI Shorts Factory 3.0")
st.caption("Референс → оригинальный сценарий → AI-картинки → голос → субтитры → MP4")

if "stage" not in st.session_state: st.session_state.stage=0
for k in ["analysis","concepts","script","assets","video"]:
    if k not in st.session_state: st.session_state[k]=None

with st.expander("⚙️ Настройки", expanded=True):
    if not os.getenv("OPENAI_API_KEY"):
        st.warning("Для реальной генерации добавь OPENAI_API_KEY в Secrets/Environment.")
    language=st.selectbox("Язык ролика",["Русский","Türkçe","English"])
    duration=st.selectbox("Длительность",["30","45","60"],index=1)
    style=st.selectbox("Стиль",["Динамичный viral Shorts","Minecraft / gaming","Факты / история","Мотивация","Комедия"])

url=st.text_input("🔗 Ссылка на видео-референс",placeholder="YouTube URL")
if st.button("1️⃣ АНАЛИЗИРОВАТЬ РЕФЕРЕНС",type="primary"):
    if not url.strip(): st.error("Вставь ссылку.")
    else:
        with st.spinner("Анализирую структуру..."):
            st.session_state.analysis=analyze_reference(url)
            st.session_state.concepts=make_concepts(st.session_state.analysis,language,style)
        st.session_state.stage=1

if st.session_state.analysis:
    a=st.session_state.analysis
    st.subheader("📊 Анализ")
    st.write("**Название:**",a["title"])
    st.write("**Канал:**",a["channel"])
    st.write("**Длительность:**",a["duration"])
    st.write("**Структура:**",a["structure"])
    st.subheader("💡 Выбери концепцию")
    for i,c in enumerate(st.session_state.concepts):
        with st.container(border=True):
            st.markdown(f"### {i+1}. {c['title']}")
            st.write(c["description"])
            st.caption("Хук: "+c["hook"])
            if st.button(f"Выбрать {i+1}",key=f"c{i}"):
                with st.spinner("Пишу оригинальный сценарий и раскадровку..."):
                    st.session_state.script=make_script(a,c,language,int(duration),style)
                st.session_state.stage=2
                st.rerun()

if st.session_state.script:
    s=st.session_state.script
    st.divider(); st.subheader("📝 Сценарий")
    st.write("**Название:**",s["title"])
    st.text_area("Озвучка",s["voiceover"],height=220)
    for x in s["scenes"]:
        st.markdown(f"**Сцена {x['scene']} — {x['seconds']} сек.**")
        st.caption(x["visual_prompt"])
    if st.button("2️⃣ СОЗДАТЬ AI-КАДРЫ + ОЗВУЧКУ",type="primary"):
        with st.spinner("Генерирую изображения и голос... Это может занять несколько минут."):
            st.session_state.assets=generate_assets(s)
        st.session_state.stage=3
        st.rerun()

if st.session_state.assets:
    st.divider(); st.subheader("🎨 Материалы готовы")
    if st.session_state.assets.get("images"):
        cols=st.columns(min(3,len(st.session_state.assets["images"])))
        for i,img in enumerate(st.session_state.assets["images"]):
            with cols[i%len(cols)]: st.image(img,caption=f"Кадр {i+1}")
    if st.session_state.assets.get("audio"):
        st.audio(st.session_state.assets["audio"])
    if st.button("3️⃣ СОБРАТЬ ФИНАЛЬНЫЙ SHORTS",type="primary"):
        with st.spinner("Монтаж: 9:16 + движение + субтитры + звук..."):
            st.session_state.video=render_video(st.session_state.script,st.session_state.assets)
        st.session_state.stage=4

if st.session_state.video:
    st.divider(); st.subheader("🎉 Готово")
    st.video(st.session_state.video)
    with open(st.session_state.video,"rb") as f:
        st.download_button("⬇️ СКАЧАТЬ ГОТОВЫЙ MP4",f,file_name="shorts_factory_3.mp4",mime="video/mp4")
    st.info("Референс используется как источник идеи/структуры. Финальный ролик генерируется заново, а не копирует исходное видео.")
