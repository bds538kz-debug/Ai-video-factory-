# AI Video Factory 3.0 — REAL SHORTS

Cloud-ready Streamlit MVP.

Flow:
URL → reference metadata → 5 original concepts → original script/storyboard → AI images → AI voice → 9:16 MP4 → subtitles.

For Streamlit Community Cloud:
- main file: app.py
- requirements: requirements.txt
- system package: packages.txt (ffmpeg)
- add OPENAI_API_KEY in Streamlit Secrets, never in GitHub.

The reference is not inserted into the final video. Assets are generated anew.
