
import os, json, re, subprocess, tempfile, base64
from pathlib import Path

def client():
    from openai import OpenAI
    key=os.getenv("OPENAI_API_KEY")
    if not key: raise RuntimeError("Нет OPENAI_API_KEY.")
    return OpenAI(api_key=key)

def analyze_reference(url):
    title,channel,duration="Референс","—","—"
    try:
        import yt_dlp
        with yt_dlp.YoutubeDL({"quiet":True,"skip_download":True,"no_warnings":True}) as y:
            x=y.extract_info(url,download=False)
        title=x.get("title") or title
        channel=x.get("channel") or x.get("uploader") or channel
        if x.get("duration"): duration=f"{int(x['duration'])//60}:{int(x['duration'])%60:02d}"
    except Exception: pass
    return {"url":url,"title":title,"channel":channel,"duration":duration,
            "structure":"хук → быстрое развитие → визуальная смена → кульминация → вопрос/CTA"}

def ask(prompt):
    r=client().responses.create(model=os.getenv("TEXT_MODEL","gpt-5.6"),input=prompt)
    return r.output_text

def make_concepts(a,language,style):
    p=f"""Create 5 ORIGINAL YouTube Shorts concepts inspired only by the structure/topic of this reference.
Do not copy its script, scenes, characters, footage or wording.
Language: {language}. Style: {style}.
Reference title: {a['title']}. Return ONLY JSON array with title, description, hook."""
    try:
        return json.loads(ask(p))
    except Exception:
        return [{"title":"Неожиданный поворот","description":"Оригинальная история с сильным финалом.","hook":"Ты точно не ожидал этого..."}]*5

def make_script(a,c,language,duration,style):
    p=f"""Create an ORIGINAL {duration}-second YouTube Short.
Language: {language}. Style: {style}.
Concept: {json.dumps(c,ensure_ascii=False)}
Reference title is only inspiration: {a['title']}.
Never reproduce copyrighted dialogue or footage. Make a fresh story.
Return ONLY JSON:
{{"title":"...","voiceover":"...","scenes":[{{"scene":1,"seconds":5,"visual_prompt":"English prompt for an original vertical image"}}]}}
Need 4-8 scenes, total seconds approximately {duration}. Visual prompts must be safe, detailed, cinematic, 9:16, no text/logos."""
    return json.loads(ask(p))

def generate_assets(script):
    out=Path(tempfile.mkdtemp(prefix="shorts3_"))
    images=[]
    c=client()
    for i,sc in enumerate(script["scenes"]):
        prompt=sc["visual_prompt"]+" vertical 9:16, cinematic, high detail"
        res=c.images.generate(model=os.getenv("IMAGE_MODEL","gpt-image-1"),prompt=prompt,size="1024x1536")
        b64=getattr(res.data[0],"b64_json",None)
        if b64:
            p=out/f"img_{i:02d}.png"; p.write_bytes(base64.b64decode(b64)); images.append(str(p))
    audio=out/"voice.mp3"
    with c.audio.speech.with_streaming_response.create(
        model=os.getenv("TTS_MODEL","gpt-4o-mini-tts"),
        voice=os.getenv("TTS_VOICE","alloy"),
        input=script["voiceover"]
    ) as r: r.stream_to_file(audio)
    return {"dir":str(out),"images":images,"audio":str(audio)}

def render_video(script,assets):
    out=Path(assets["dir"])/"final_short.mp4"
    srt=Path(assets["dir"])/"captions.srt"
    # Simple timed captions; scenes are used as visual timeline.
    t=0; lines=[]
    def ts(x):
        h=int(x//3600); m=int((x%3600)//60); sec=int(x%60); ms=int((x-int(x))*1000)
        return f"{h:02d}:{m:02d}:{sec:02d},{ms:03d}"
    words=re.findall(r'\S+',script["voiceover"])
    chunks=[]; step=max(1,len(words)//max(1,len(script["scenes"])))
    for i in range(0,len(words),step): chunks.append(" ".join(words[i:i+step]))
    for i,ch in enumerate(chunks):
        start=sum(int(x["seconds"]) for x in script["scenes"][:i])
        end=sum(int(x["seconds"]) for x in script["scenes"][:min(i+1,len(script["scenes"]))])
        lines.append(f"{i+1}\n{ts(start)} --> {ts(end)}\n{ch}\n")
    srt.write_text("\n".join(lines),encoding="utf-8")
    # Create each still as a moving 9:16 clip, then concatenate.
    clips=[]
    for i,img in enumerate(assets["images"]):
        dur=script["scenes"][i]["seconds"]
        clip=Path(assets["dir"])/f"clip_{i:02d}.mp4"
        vf="scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920,zoompan=z='min(zoom+0.0008,1.08)':d=1:s=1080x1920:fps=30"
        subprocess.run(["ffmpeg","-y","-loop","1","-i",img,"-t",str(dur),"-vf",vf,"-c:v","libx264","-pix_fmt","yuv420p",str(clip)],
                       check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        clips.append(clip)
    concat=Path(assets["dir"])/"concat.txt"
    concat.write_text("\n".join(f"file '{x}'" for x in clips),encoding="utf-8")
    silent=Path(assets["dir"])/"video.mp4"
    subprocess.run(["ffmpeg","-y","-f","concat","-safe","0","-i",str(concat),"-c","copy",str(silent)],
                   check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    subprocess.run(["ffmpeg","-y","-i",str(silent),"-i",assets["audio"],"-vf",
                    f"subtitles={srt}:force_style='FontSize=18,Alignment=2,MarginV=120,Outline=2'",
                    "-map","0:v:0","-map","1:a:0","-shortest","-c:v","libx264","-c:a","aac","-pix_fmt","yuv420p",str(out)],
                   check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    return str(out)
